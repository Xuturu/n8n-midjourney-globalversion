import os
from src.utils.config import Config

# Выводим текущую рабочую директорию
print(f"Current working directory: {os.getcwd()}")
# Проверяем наличие файла конфигурации
print(f"Config file exists: {os.path.exists('config.yaml')}")

if os.path.exists('config.yaml'):
    print("✅ config.yaml found")
    try:
        # Загружаем конфиг с помощью кастомного класса
        config = Config.load()
        print("✅ Config loaded successfully")
        # Показываем первые символы токена (для проверки, не раскрывая полностью)
        print(f"Bot token starts with: {config.telegram.token[:10]}...")
    except Exception as e:
        print(f"❌ Config loading failed: {e}")
else:
    print("❌ config.yaml not found")
    print("Available files:", os.listdir('.'))
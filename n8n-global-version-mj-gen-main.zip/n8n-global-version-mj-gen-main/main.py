# Точка входа для запуска Telegram-бота
if __name__ == "__main__":
    print("Starting bot...")  # Для отладки
    from src.bot.telegram_bot import main  # Импорт основной функции бота
    import asyncio
    
    # Запуск асинхронного main()
    asyncio.run(main())
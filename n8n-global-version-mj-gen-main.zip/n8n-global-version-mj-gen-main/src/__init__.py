"""
PaintLLM - AI-powered image generation bot
"""

__version__ = "1.0.0"
__author__ = "PaintLLM Team"
__description__ = "Telegram bot for generating images using MidJourney API"
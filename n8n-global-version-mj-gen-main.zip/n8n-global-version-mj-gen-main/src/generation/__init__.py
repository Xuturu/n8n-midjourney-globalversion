"""
Generation module for PaintLLM
Contains prompt generation and MidJourney API client
"""

from .prompt_generator import PromptGenerator
from .midjourney_client import MidJourneyClient

__all__ = ["PromptGenerator", "MidjourneyClient"]

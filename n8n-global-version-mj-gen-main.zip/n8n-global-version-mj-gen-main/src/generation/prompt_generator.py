"""
Prompt generator module using OpenRouter API
"""

import json
from typing import Dict, Any

import httpx
from loguru import logger


class PromptGenerator:
    """Generate MidJourney prompts using LLM"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.api_url = "https://openrouter.ai/api/v1/chat/completions"
        self.headers = {
            "Authorization": "Bearer {config['api_key']}",
            "Content-Type": "application/json",
        }

    async def generate_prompt(self, text: str) -> Dict[str, str]:
        """Generate MidJourney prompt from text description"""
        
        system_prompt = self.config.get('system_prompt', self._get_default_prompt())
        
        payload = {
            "model": self.config.get('model', 'anthropic/claude-3-opus'),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ],
            "temperature": self.config.get('temperature', 0.7),
            "max_tokens": self.config.get('max_tokens', 500),
        }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.api_url,
                    headers=self.headers,
                    json=payload,
                    timeout=30.0
                )
                response.raise_for_status()
                
                result = response.json()
                content = result['choices'][0]['message']['content']
                
                # Parse JSON response
                prompt_data = json.loads(content)
                
                logger.info(f"Generated prompt: {prompt_data['prompt'][:100]}...")
                return prompt_data
                
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response: {e}")
            # Fallback to simple prompt
            return {
                "prompt": f"{text} --v 7 --quality 2",
                "style": "realistic",
                "aspect_ratio": "1:1"
            }
        except Exception as e:
            logger.error(f"Prompt generation failed: {e}")
            raise

    def _get_default_prompt(self) -> str:
        """Get default system prompt"""
        return """You are an expert at creating MidJourney prompts. Generated using --v 7 engine.
Create detailed, artistic prompts that accurately represent scenes from text paragraphs.
Each generated image must accurately and relevantly describe the scene from the paragraph.
Some paragraphs depict short dialogues between characters. If the characters are well-known, 
they should be depicted in a recognizable manner.

Include style, lighting, mood, composition. Avoid typical AI artifacts like incorrect fingers 
or face distortions. 

Output ONLY a JSON object with:
{
    "prompt": "detailed MidJourney prompt ending with --v 7",
    "negative_prompt": "things to avoid",
    "style": "artistic style",
    "aspect_ratio": "1:1"
}

The prompt must:
- Accurately depict the scene described
- Include all relevant characters and elements
- Resemble known characters if they are mentioned
- Avoid typical MidJourney issues
- Emphasize cinematic composition, emotional atmosphere, realistic lighting, ultra-detailed visuals

Leave just JSON uncluttered without markdown formatting."""
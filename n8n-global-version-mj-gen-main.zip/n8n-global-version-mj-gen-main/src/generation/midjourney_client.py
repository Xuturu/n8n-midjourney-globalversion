"""
MidJourney API client module
"""

import asyncio
from typing import Dict, Any, Optional

import httpx
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential


class MidJourneyClient:
    """Client for MidJourney API via mjapi.io"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.api_url = getattr(config,'api_url', 'https://api.userapi.ai/midjourney/v2')
        self.headers = {
            "Authorization": "Bearer {config['api_key']}",
            "Content-Type": "application/json",
        }
        self.timeout = getattr(config,'timeout', 120)

    async def generate_image(self, prompt: str) -> Dict[str, Any]:
        """Start image generation"""
        
        payload = {
            "prompt": prompt,
            "version": str(getattr(self.config, 'version', 7)),
            "quality": str(getattr(self.config, 'quality', 2)),
            "stylize": str(getattr(self.config, 'stylize', 100)),
        }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.api_url}/imagine",
                    headers=self.headers,
                    json=payload,
                    timeout=30.0
                )
                response.raise_for_status()
                
                result = response.json()
                logger.info(f"Started generation with hash: {result.get('hash')}")
                return result
                
        except Exception as e:
            logger.error(f"Failed to start generation: {e}")
            raise

    @retry(
        stop=stop_after_attempt(30),
        wait=wait_exponential(multiplier=2, min=5, max=30)
    )
    async def wait_for_result(self, hash: str) -> str:
        """Wait for generation to complete and return image URL"""
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.api_url}/status",
                headers=self.headers,
                params={"hash": hash},
                timeout=10.0
            )
            response.raise_for_status()
            
            result = response.json()
            status = result.get('status')
            
            logger.debug(f"Generation status for {hash}: {status}")
            
            if status == 'completed':
                # Get the first upscaled image
                image_url = result['result']['proxy_url']
                
                # Upscale if needed
                if getattr(self.config, 'auto_upscale', True):
                    image_url = await self._upscale_image(hash, 1)
                
                return image_url
                
            elif status == 'failed':
                error = result.get('error', 'Unknown error')
                raise Exception(f"Generation failed: {error}")
                
            else:
                # Still processing, retry
                raise Exception("Still processing")

    async def _upscale_image(self, hash: str, choice: int = 1) -> str:
        """Upscale generated image"""
        
        payload = {
            "hash": hash,
            "choice": choice
        }
        
        try:
            async with httpx.AsyncClient() as client:
                # Start upscale
                response = await client.post(
                    f"{self.api_url}/upscale",
                    headers=self.headers,
                    json=payload,
                    timeout=30.0
                )
                response.raise_for_status()
                
                upscale_result = response.json()
                upscale_hash = upscale_result.get('hash')
                
                # Wait for upscale to complete
                await asyncio.sleep(10)  # Initial wait
                
                # Poll for upscale result
                for _ in range(10):
                    response = await client.get(
                        f"{self.api_url}/status",
                        headers=self.headers,
                        params={"hash": upscale_hash},
                        timeout=10.0
                    )
                    
                    result = response.json()
                    if result.get('status') == 'completed':
                        return result['result']['proxy_url']
                    
                    await asyncio.sleep(5)
                
                # Fallback to original if upscale fails
                logger.warning("Upscale timeout, using original image")
                return await self._get_original_image(hash)
                
        except Exception as e:
            logger.error(f"Upscale failed: {e}")
            return await self._get_original_image(hash)

    async def _get_original_image(self, hash: str) -> str:
        """Get original image URL"""
        
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.api_url}/status",
                headers=self.headers,
                params={"hash": hash},
                timeout=10.0
            )
            response.raise_for_status()
            
            result = response.json()
            return result['result']['proxy_url']
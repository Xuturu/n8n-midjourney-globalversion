// MongoDB initialization script

// Switch to the paintllm database
db = db.getSiblingDB('paintllm');

// Create collections with validation
db.createCollection('users', {
  validator: {
    $jsonSchema: {
      bsonType: 'object',
      required: ['telegram_id', 'created_at'],
      properties: {
        telegram_id: {
          bsonType: 'long',
          description: 'Telegram user ID'
        },
        username: {
          bsonType: 'string',
          description: 'Telegram username'
        },
        first_name: {
          bsonType: 'string',
          description: 'User first name'
        },
        last_name: {
          bsonType: 'string',
          description: 'User last name'
        },
        created_at: {
          bsonType: 'date',
          description: 'Account creation date'
        },
        last_active: {
          bsonType: 'date',
          description: 'Last activity date'
        },
        total_generations: {
          bsonType: 'int',
          description: 'Total number of generations'
        }
      }
    }
  }
});

db.createCollection('generation_logs', {
  validator: {
    $jsonSchema: {
      bsonType: 'object',
      required: ['telegram_id', 'original_text', 'timestamp', 'status'],
      properties: {
        telegram_id: {
          bsonType: 'long'
        },
        username: {
          bsonType: 'string'
        },
        original_text: {
          bsonType: 'string'
        },
        generated_prompt: {
          bsonType: 'string'
        },
        midjourney_hash: {
          bsonType: 'string'
        },
        image_url: {
          bsonType: 'string'
        },
        timestamp: {
          bsonType: 'date'
        },
        status: {
          enum: ['pending', 'prompt_generated', 'generating', 'completed', 'failed']
        },
        error_message: {
          bsonType: 'string'
        },
        generation_time: {
          bsonType: 'double'
        }
      }
    }
  }
});

// Create indexes
db.users.createIndex({ 'telegram_id': 1 }, { unique: true });
db.users.createIndex({ 'username': 1 });
db.generation_logs.createIndex({ 'telegram_id': 1 });
db.generation_logs.createIndex({ 'timestamp': -1 });
db.generation_logs.createIndex({ 'status': 1 });
db.generation_logs.createIndex({ 'midjourney_hash': 1 });

// Create error logs collection
db.createCollection('error_logs');
db.error_logs.createIndex({ 'timestamp': -1 });
db.error_logs.createIndex({ 'error_type': 1 });

print('MongoDB initialization completed');
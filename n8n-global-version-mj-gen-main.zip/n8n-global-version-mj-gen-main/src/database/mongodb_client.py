"""
MongoDB client module
"""

from datetime import datetime
from typing import Dict, Any, Optional

from motor.motor_asyncio import AsyncIOMotorClient
from loguru import logger
from bson import ObjectId
from src.utils.config import MongoDBConfig


class MongoDBClient:
    """MongoDB async client"""

    def __init__(self, config: MongoDBConfig):
        self.config = config
        self.client: Optional[AsyncIOMotorClient] = None
        self.db = None

    async def connect(self) -> None:
        """Connect to MongoDB"""
        try:
            # Fixed: Use attribute access instead of dictionary access
            self.client = AsyncIOMotorClient(self.config.connection_string)
            # Fixed: Use square brackets for database selection, not parentheses
            self.db = self.client[self.config.database_name]
            
            # Test connection
            await self.client.admin.command('ping')
            logger.info("Connected to MongoDB")
            
        except Exception as e:
            logger.error(f"MongoDB connection failed: {e}")
            raise

    async def close(self) -> None:
        """Close MongoDB connection"""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")

    async def upsert_user(self, user_data: Dict[str, Any]) -> None:
        """Insert or update user"""
        # Fixed: Use attribute access for collection name
        collection = self.db[self.config.users_collection]
        
        user_data['last_active'] = datetime.utcnow()
        
        await collection.update_one(
            {'telegram_id': user_data['telegram_id']},
            {
                '$set': user_data,
                '$setOnInsert': {
                    'created_at': datetime.utcnow(),
                    'total_generations': 0
                }
            },
            upsert=True
        )

    async def create_generation_log(self, log_data: Dict[str, Any]) -> str:
        """Create generation log entry"""
        # Fixed: Use attribute access for collection name
        collection = self.db[self.config.generations_collection]
        
        log_data['timestamp'] = datetime.utcnow()
        
        result = await collection.insert_one(log_data)
        return str(result.inserted_id)

    async def update_generation_log(
        self, 
        generation_id: str, 
        update_data: Dict[str, Any]
    ) -> None:
        """Update generation log"""
        # Fixed: Use attribute access for collection name
        collection = self.db[self.config.generations_collection]
        
        update_data['updated_at'] = datetime.utcnow()
        
        await collection.update_one(
            {'_id': ObjectId(generation_id)},
            {'$set': update_data}
        )

    async def get_user_stats(self, telegram_id: int) -> Dict[str, Any]:
        """Get user statistics"""
        # Fixed: Use attribute access for collection names
        users_collection = self.db[self.config.users_collection]
        generations_collection = self.db[self.config.generations_collection]
        
        user = await users_collection.find_one({'telegram_id': telegram_id})
        
        if not user:
            return {}
        
        # Count generations
        total_generations = await generations_collection.count_documents({
            'telegram_id': telegram_id,
            'status': 'completed'
        })
        
        # Update user stats
        await users_collection.update_one(
            {'telegram_id': telegram_id},
            {'$set': {'total_generations': total_generations}}
        )
        
        return {
            'total_generations': total_generations,
            'created_at': user.get('created_at'),
            'last_active': user.get('last_active')
        }

    async def log_error(self, error_data: Dict[str, Any]) -> None:
        """Log error to database"""
        # Use a default collection name for errors since it's not in config
        collection = self.db['errors']
        
        error_data['timestamp'] = datetime.utcnow()
        
        await collection.insert_one(error_data)
"""
Database module for PaintLLM
Contains MongoDB client and data models
"""

from .mongodb_client import MongoDBClient
# from .models import ChatMessage, GenerationResult, UserSession

__all__ = ["MongoDBClient", "ChatMessage", "GenerationResult", "UserSession"]
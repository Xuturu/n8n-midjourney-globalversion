#!/usr/bin/env python3
"""
Message handlers for PaintLLM bot
"""

from typing import Optional
from aiogram import Dispatcher, types
from aiogram.filters import Command, CommandStart
from loguru import logger

from src.database.mongodb_client import MongoDBClient
from src.generation.midjourney_client import MidJourneyClient
from src.generation.prompt_generator import PromptGenerator
from src.utils.config import Config
from src.utils.rate_limiter import RateLimiter


class MessageHandlers:
    """Handles all Telegram message types and commands"""
    
    def __init__(
        self, 
        db: MongoDBClient,
        prompt_generator: PromptGenerator,
        midjourney: MidJourneyClient,
        rate_limiter: RateLimiter,
        config: Config
    ):
        self.db = db
        self.prompt_generator = prompt_generator
        self.midjourney = midjourney
        self.rate_limiter = rate_limiter
        self.config = config

    def register_handlers(self, dp: Dispatcher) -> None:
        """Register all handlers with the dispatcher"""
        dp.message(CommandStart())(self.cmd_start)
        dp.message(Command("help"))(self.cmd_help)
        dp.message()(self.handle_text_message)

    async def cmd_start(self, message: types.Message) -> None:
        """Handle /start command"""
        user_id = message.from_user.id
        username = message.from_user.username
        
        # Save user to database
        await self.db.upsert_user({
            "telegram_id": user_id,
            "username": username,
            "first_name": message.from_user.first_name,
            "last_name": message.from_user.last_name,
        })
        
        welcome_text = (
            "🎨 Добро пожаловать в PaintLLM!\n\n"
            "Я могу создавать изображения по вашему текстовому описанию.\n"
            "Просто отправьте мне описание сцены, персонажа или момента, "
            "и я создам для вас уникальное изображение!\n\n"
            "Используйте /help для получения дополнительной информации."
        )
        
        await message.answer(welcome_text)
        logger.info(f"New user started bot: {user_id} (@{username})")

    async def cmd_help(self, message: types.Message) -> None:
        """Handle /help command"""
        help_text = (
            "📚 Как использовать бота:\n\n"
            "1. Отправьте текстовое описание сцены\n"
            "2. Бот создаст оптимальный промпт для MidJourney\n"
            "3. Дождитесь генерации (обычно 1-2 минуты)\n"
            "4. Получите готовое изображение!\n\n"
            "💡 Советы:\n"
            "• Чем детальнее описание, тем лучше результат\n"
            "• Указывайте стиль, освещение, настроение\n"
            "• Если персонажи известные - укажите их имена\n\n"
            f"⚡ Лимит: {self.config.rate_limiting.max_requests_per_user} запросов в час"
        )
        
        await message.answer(help_text)

    async def handle_text_message(self, message: types.Message) -> None:
        """Handle text messages for image generation"""
        user_id = message.from_user.id
        username = message.from_user.username
        text = message.text
        
        # Check rate limit
        if not await self.rate_limiter.check_limit(user_id):
            await message.answer(
                "⏳ Превышен лимит запросов. "
                "Попробуйте позже или подождите час."
            )
            return
        
        # Log generation request
        generation_id = await self.db.create_generation_log({
            "telegram_id": user_id,
            "username": username,
            "original_text": text,
            "status": "pending"
        })
        
        try:
            # Send processing message
            processing_msg = await message.answer(
                "🎨 Анализирую ваш запрос и создаю промпт...\n"
                "Это может занять минуту."
            )
            
            # Generate prompt
            prompt_data = await self.prompt_generator.generate_prompt(text)
            
            # Update log with prompt
            await self.db.update_generation_log(
                generation_id,
                {
                    "generated_prompt": prompt_data["prompt"],
                    "status": "prompt_generated"
                }
            )
            
            # Update message
            await processing_msg.edit_text(
                "✨ Промпт создан! Отправляю в MidJourney...\n"
                "Генерация займет 1-2 минуты."
            )
            
            # Send to MidJourney
            midjourney_result = await self.midjourney.generate_image(
                prompt_data["prompt"]
            )
            
            # Update log
            await self.db.update_generation_log(
                generation_id,
                {
                    "midjourney_hash": midjourney_result["hash"],
                    "status": "generating"
                }
            )
            
            # Wait for generation
            await processing_msg.edit_text(
                "🎨 Изображение генерируется...\n"
                "Осталось совсем немного!"
            )
            
            # Poll for result
            image_url = await self.midjourney.wait_for_result(
                midjourney_result["hash"]
            )
            
            # Update final status
            await self.db.update_generation_log(
                generation_id,
                {
                    "image_url": image_url,
                    "status": "completed"
                }
            )
            
            # Delete processing message
            await processing_msg.delete()
            
            # Send result
            await message.answer_photo(
                photo=image_url,
                caption=(
                    "🎨 Ваше изображение готово!\n\n"
                    f"📝 Промпт: {prompt_data['prompt'][:200]}..."
                    if len(prompt_data['prompt']) > 200
                    else f"📝 Промпт: {prompt_data['prompt']}"
                ),
                reply_to_message_id=message.message_id
            )
            
            logger.info(
                f"Generation completed for user {user_id}: {generation_id}"
            )
            
        except Exception as e:
            logger.error(f"Generation failed for user {user_id}: {e}")
            
            # Update log with error
            await self.db.update_generation_log(
                generation_id,
                {
                    "status": "failed",
                    "error_message": str(e)
                }
            )
            
            # Notify user
            await message.answer(
                "❌ Произошла ошибка при генерации изображения.\n"
                "Пожалуйста, попробуйте еще раз или измените описание.",
                reply_to_message_id=message.message_id
            )
#!/usr/bin/env python3
"""
Main Telegram bot module for PaintLLM
"""

import asyncio
from typing import Optional

from aiogram import Bot, Dispatcher, types
from loguru import logger


from src.database.mongodb_client import MongoDBClient
from src.generation.midjourney_client import MidJourneyClient
from src.generation.prompt_generator import PromptGenerator
from src.utils.config import Config
from src.utils.rate_limiter import RateLimiter
from .handlers import MessageHandlers


class PaintLLMBot:
    """Main bot class for PaintLLM"""

    def __init__(self, config: Config):
        self.config = config
        self.bot = Bot(token=config.telegram.token)
        self.dp = Dispatcher()
        self.db = MongoDBClient(config.mongodb)
        self.prompt_generator = PromptGenerator(config.openrouter)
        self.midjourney = MidJourneyClient(config.midjourney)
        self.rate_limiter = RateLimiter(config.rate_limiting)
        
        # Initialize handlers
        self.handlers = MessageHandlers(
            db=self.db,
            prompt_generator=self.prompt_generator,
            midjourney=self.midjourney,
            rate_limiter=self.rate_limiter,
            config=self.config
        )
        
        self._register_handlers()
        logger.info("PaintLLM bot initialized")

    def _register_handlers(self) -> None:
        """Register all bot handlers"""
        self.handlers.register_handlers(self.dp)

    async def start(self) -> None:
        """Start the bot"""
        logger.info("Starting PaintLLM bot...")
        await self.db.connect()
        await self.dp.start_polling(self.bot)

    async def stop(self) -> None:
        """Stop the bot"""
        logger.info("Stopping PaintLLM bot...")
        await self.bot.session.close()
        await self.db.close()


async def main():
    """Main entry point"""
    config = Config.load()
    bot = PaintLLMBot(config)
    
    try:
        await bot.start()
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    finally:
        await bot.stop()


if __name__ == "__main__":
    asyncio.run(main())
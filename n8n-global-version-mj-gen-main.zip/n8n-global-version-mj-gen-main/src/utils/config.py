import os
from dataclasses import dataclass
from typing import Optional
import yaml

# --- Описываем структуру конфигов для разных сервисов ---
@dataclass
class TelegramConfig:
    token: str  # Токен Telegram-бота

@dataclass
class MidjourneyConfig:
    api_url: str = "https://api.userapi.ai/midjourney/v2"  # URL API MidJourney
    api_key: str = ""  # API-ключ
    timeout: int = 120  # Таймаут (сек)

@dataclass
class MongoDBConfig:
    connection_string: str  # URI для подключения
    database_name: str = "paintllm"
    users_collection: str = "users"
    generations_collection: str = "generations"

@dataclass
class OpenRouterConfig:
    api_key: str  # API-ключ OpenRouter
    model: str = "openai/gpt-4o-mini"
    base_url: str = "https://openrouter.ai/api/v1"

@dataclass
class RateLimitingConfig:
    max_requests_per_user: int = 10  # Максимум запросов
    time_window_hours: int = 1  # Окно времени (часы)

@dataclass
class Config:
    telegram: TelegramConfig
    midjourney: MidjourneyConfig
    mongodb: MongoDBConfig
    openrouter: OpenRouterConfig
    rate_limiting: RateLimitingConfig
    log_level: str = "INFO"
    
    @classmethod
    def load(cls, config_path: str = "config.yaml") -> "Config":
        """
        Загружает конфиг из YAML-файла и переменных окружения.
        Переменные окружения имеют приоритет над файлом.
        """
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                data = yaml.safe_load(f)
        else:
            data = {}
        # Переменные окружения перекрывают значения из файла
        return cls(
            telegram=TelegramConfig(
                token=os.getenv("TELEGRAM_BOT_TOKEN", data.get("telegram", {}).get("token", ""))
            ),
            midjourney=MidjourneyConfig(
                api_key=os.getenv("MIDJOURNEY_API_KEY", data.get("midjourney", {}).get("api_key", "")),
                api_url=os.getenv("MIDJOURNEY_API_URL", data.get("midjourney", {}).get("api_url", "https://api.userapi.ai/midjourney/v2")),
                timeout=int(os.getenv("MIDJOURNEY_TIMEOUT", data.get("midjourney", {}).get("timeout", 120)))
            ),
            mongodb=MongoDBConfig(
                connection_string=os.getenv("MONGODB_CONNECTION_STRING", data.get("mongodb", {}).get("connection_string", "")),
                database_name=os.getenv("MONGODB_DATABASE", data.get("mongodb", {}).get("database_name", "paintllm")),
                users_collection=os.getenv("MONGODB_USERS_COLLECTION", data.get("mongodb", {}).get("users_collection", "users")),
                generations_collection=os.getenv("MONGODB_GENERATIONS_COLLECTION", data.get("mongodb", {}).get("generations_collection", "generations"))
            ),
            openrouter=OpenRouterConfig(
                api_key=os.getenv("OPENROUTER_API_KEY", data.get("openrouter", {}).get("api_key", "")),
                model=os.getenv("OPENROUTER_MODEL", data.get("openrouter", {}).get("model", "openai/gpt-4o-mini")),
                base_url=os.getenv("OPENROUTER_BASE_URL", data.get("openrouter", {}).get("base_url", "https://openrouter.ai/api/v1"))
            ),
            rate_limiting=RateLimitingConfig(
                max_requests_per_user=int(os.getenv("RATE_LIMIT_MAX_REQUESTS", data.get("rate_limiting", {}).get("max_requests_per_user", 10))),
                time_window_hours=int(os.getenv("RATE_LIMIT_TIME_WINDOW", data.get("rate_limiting", {}).get("time_window_hours", 1)))
            ),
            log_level=os.getenv("LOG_LEVEL", data.get("log_level", "INFO"))
        )

# --- Глобальный синглтон-конфиг для совместимости ---
config = None

def get_config() -> Config:
    """
    Возвращает глобальный экземпляр конфига (ленивая инициализация).
    """
    global config
    if config is None:
        config = Config.load()
    return config
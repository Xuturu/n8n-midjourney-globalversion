"""
Rate limiting module
Модуль ограничения частоты запросов (rate limiting) для пользователей.
"""

from datetime import datetime, timedelta
from typing import Dict, Any
from collections import defaultdict
import asyncio


class RateLimiter:
    """
    Простой in-memory rate limiter для ограничения числа запросов от пользователя за определённый период.
    Не требует внешнего хранилища, подходит для небольших проектов или тестов.
    """

    def __init__(self, config: Dict[str, Any]):
        # Включено ли ограничение
        self.enabled = getattr(config,'enabled', True)
        # Максимум запросов на пользователя
        self.max_requests = getattr(config,'max_requests_per_user', 10)
        # Окно времени (секунды)
        self.time_window = getattr(config,'time_window', 3600)
        # Словарь: user_id -> список времён запросов
        self.user_requests = defaultdict(list)
        self._cleanup_task = None

    async def check_limit(self, user_id: int) -> bool:
        """
        Проверяет, может ли пользователь сделать новый запрос.
        Возвращает True, если лимит не превышен, иначе False.
        """
        if not self.enabled:
            return True
        now = datetime.utcnow()
        cutoff_time = now - timedelta(seconds=self.time_window)
        # Очищаем старые запросы
        self.user_requests[user_id] = [
            req_time for req_time in self.user_requests[user_id]
            if req_time > cutoff_time
        ]
        # Проверяем лимит
        if len(self.user_requests[user_id]) >= self.max_requests:
            return False
        # Добавляем новый запрос
        self.user_requests[user_id].append(now)
        return True

    async def start_cleanup_task(self) -> None:
        """
        Запускает периодическую очистку старых запросов (асинхронно).
        Нужно для долгоживущих приложений, чтобы не накапливать память.
        """
        async def cleanup():
            while True:
                await asyncio.sleep(600)  # Очистка каждые 10 минут
                now = datetime.utcnow()
                cutoff_time = now - timedelta(seconds=self.time_window)
                # Очищаем для всех пользователей
                for user_id in list(self.user_requests.keys()):
                    self.user_requests[user_id] = [
                        req_time for req_time in self.user_requests[user_id]
                        if req_time > cutoff_time
                    ]
                    # Удаляем пользователя, если нет запросов
                    if not self.user_requests[user_id]:
                        del self.user_requests[user_id]
        self._cleanup_task = asyncio.create_task(cleanup())

    def stop_cleanup_task(self) -> None:
        """
        Останавливает задачу очистки (если была запущена).
        """
        if self._cleanup_task:
            self._cleanup_task.cancel()
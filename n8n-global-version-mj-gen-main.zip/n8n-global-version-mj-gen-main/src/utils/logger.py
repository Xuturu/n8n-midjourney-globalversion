"""
Logger configuration module
Модуль настройки логирования через loguru для PaintLLM.
"""

import sys
from pathlib import Path
from loguru import logger


def setup_logger(config: dict) -> None:
    """
    Конфигурирует loguru logger для вывода в консоль и файл.
    Поддерживает ротацию, формат, уровень логирования и архивирование логов.
    """
    # Удаляем стандартный handler loguru
    logger.remove()
    # Добавляем вывод в консоль
    logger.add(
        sys.stdout,
        level=config.get('level', 'INFO'),
        format=config.get('format', '{time} | {level} | {message}'),
        colorize=True
    )
    # Добавляем вывод в файл с ротацией и архивированием
    log_file = Path(config.get('file', 'logs/paintllm.log'))
    log_file.parent.mkdir(parents=True, exist_ok=True)
    logger.add(
        log_file,
        level=config.get('level', 'INFO'),
        format=config.get('format', '{time} | {level} | {message}'),
        rotation=config.get('max_size', '10 MB'),
        retention=config.get('backup_count', 5),
        compression="zip"
    )
    logger.info("Logger configured successfully")
"""
Utils module for PaintLLM
Contains configuration management and logging utilities
Модуль утилит: конфиг, логгер и вспомогательные функции для PaintLLM.
"""

from .config import config, Config
from .logger import setup_logger

# Экспортируемые объекты для удобного импорта
__all__ = ["config", "Config", "setup_logger", "get_logger"]
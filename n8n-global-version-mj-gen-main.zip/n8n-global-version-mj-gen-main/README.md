# PaintLLM - Telegram MidJourney Bot
# -----------------------------------
# Этот проект демонстрирует интеграцию Telegram-бота с MidJourney API через n8n и LLM (OpenRouter).
# В README подробно описаны архитектура, структура, запуск, безопасность и тестирование.
# Ключевые моменты отмечены комментариями для демонстрации умений.

## 📋 Описание

Telegram-бот для генерации изображений через MidJourney API. Бот принимает текстовые описания сцен из любой вселенной и создает детализированные изображения с помощью AI.

### Функциональность

- 🎨 Генерация изображений по текстовому описанию
- 🤖 Использование LLM для создания оптимальных промптов MidJourney
- 💾 Сохранение истории генераций в MongoDB
- 📊 Полное логирование всех операций
- 🖼️ Вывод изображений в формате PNG/JPEG с разрешением 1024x1024
- 🔄 Интеграция с n8n для автоматизации workflow

## 🚀 Быстрый старт

### Предварительные требования

- Docker и Docker Compose
- Telegram Bot Token
- OpenRouter API ключ
- MidJourney API доступ (через userapi.ai)
- MongoDB (локально или облачный)

### Установка и запуск

1. Клонируйте репозиторий:
```bash
git clone https://github.com/Xuturu/paintllm-main.git
cd paintllm
```

2. Настройте конфигурацию:
   - Отредактируйте `config.yaml` с вашими API ключами и настройками
   - Или используйте переменные окружения в `docker-compose.yml`

3. Запустите через Docker Compose:
```bash
docker-compose up -d
```

4. Откройте n8n интерфейс:
   - Перейдите по адресу: http://localhost:5678
   - Импортируйте workflow из `n8n/workflow.json`
   - Настройте credentials для всех нод
   - Активируйте workflow

### Альтернативный запуск (без n8n)

Если вы хотите запустить только Telegram бота без n8n:

```bash
# Создайте отдельный docker-compose файл для бота
docker build -t paintllm-bot .
docker run -d \
  --name paintllm-bot \
  -v $(pwd)/config.yaml:/app/config.yaml \
  -v $(pwd)/logs:/app/logs \
  paintllm-bot
```

## ⚙️ Конфигурация

### config.yaml

```yaml
# Telegram Bot Configuration
telegram:
  token: "YOUR_TELEGRAM_BOT_TOKEN"

# MongoDB Configuration
mongodb:
  connection_string: "YOUR_MONGODB_URI"
  database_name: "paintllm"
  users_collection: "users"
  generations_collection: "generations"

# OpenRouter Configuration
openrouter:
  api_key: "YOUR_OPENROUTER_API_KEY"
  model: "openai/gpt-4o-mini"
  base_url: "https://openrouter.ai/api/v1"

# MidJourney Configuration
midjourney:
  api_key: "YOUR_userapi.ai_KEY"
  api_url: "https://api.userapi.ai/midjourney/v2"
  timeout: 120

# Rate Limiting
rate_limiting:
  max_requests_per_user: 10
  time_window_hours: 1

# Logging
log_level: "INFO"
```

### Переменные окружения (для Docker)

Все настройки можно также передать через переменные окружения:

```bash
# Telegram
TELEGRAM_BOT_TOKEN=your_token

# MongoDB
MONGODB_CONNECTION_STRING=your_mongodb_uri
MONGODB_DATABASE_NAME=paintllm
MONGODB_USERS_COLLECTION=users
MONGODB_GENERATIONS_COLLECTION=generations

# OpenRouter
OPENROUTER_API_KEY=your_openrouter_key
OPENROUTER_MODEL=openai/gpt-4o-mini
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1

# Midjourney
MIDJOURNEY_API_KEY=your_midjourney_key
MIDJOURNEY_API_URL=https://api.userapi.ai/midjourney/v2
MIDJOURNEY_TIMEOUT=120

# Rate Limiting
RATE_LIMIT_MAX_REQUESTS_PER_USER=10
RATE_LIMIT_TIME_WINDOW_HOURS=1

# Log Level
LOG_LEVEL=INFO
```

## 📁 Структура проекта

```
paintllm-main/
├── config.yaml                    # Основной конфигурационный файл
├── docker-compose.yml             # Docker Compose конфигурация
├── Dockerfile                     # Основной Dockerfile для n8n
├── main.py                        # Точка входа для Telegram бота
├── docker/                        # Docker файлы
│   ├── Dockerfile
│   ├── entrypoint.sh
│   ├── paintllm-docker-compose.txt
│   └── paintllm-dockerfile.txt
├── n8n/                           # n8n конфигурация и данные
│   ├── workflow.json              # Готовый workflow
│   ├── config/                    # n8n конфигурация
│   ├── database.sqlite            # n8n база данных
│   └── nodes/                     # Кастомные ноды
├── src/                           # Исходный код приложения
│   ├── bot/                       # Telegram бот
│   │   ├── handlers.py            # Обработчики сообщений
│   │   └── telegram_bot.py        # Основной класс бота
│   ├── database/                  # Работа с базой данных
│   │   ├── mongodb_client.py      # MongoDB клиент
│   │   └── init_mongo.js          # Инициализация MongoDB
│   ├── generation/                # Генерация изображений
│   │   ├── midjourney_client.py   # Клиент MidJourney API
│   │   └── prompt_generator.py    # Генератор промптов
│   └── utils/                     # Утилиты
│       ├── config.py              # Загрузка конфигурации
│       ├── logger.py              # Логирование
│       └── rate_limiter.py        # Ограничение запросов
├── tests/                         # Тесты
├── paintllm-config-example.txt    # Пример конфигурации
├── paintllm-requirements.txt      # Зависимости Python
└── README.md                      # Документация
```

## 🔧 n8n Workflow

Проект включает готовый n8n workflow для автоматизации процесса генерации:

1. После запуска Docker Compose откройте http://localhost:5678
2. Импортируйте `n8n/workflow.json` в вашу n8n инстанцию
3. Настройте credentials для всех нод:
   - Telegram Bot
   - MongoDB
   - OpenRouter API
   - MidJourney API
4. Активируйте workflow

### Основные компоненты workflow:

- **Telegram Trigger** - прием сообщений от пользователей
- **AI Agent** - генерация промптов через OpenRouter
- **MidJourney API** - отправка запросов на генерацию
- **MongoDB** - сохранение истории и логов
- **Response Handler** - отправка готовых изображений пользователям

## 📊 База данных

### Коллекции MongoDB:

- `users` - информация о пользователях
- `generations` - история всех генераций
- `prompts` - сохраненные промпты
- `errors` - логи ошибок

## 🛠️ API Endpoints

### MidJourney API (через userapi.ai)

- `POST /imagine` - создание изображения
- `GET /status` - проверка статуса генерации
- `POST /upscale` - увеличение разрешения

### OpenRouter API

- `POST /chat/completions` - генерация промптов через LLM

## 📝 Логирование

Все операции логируются с использованием `loguru`:

- В файл: `logs/paintllm.log`
- В MongoDB: коллекция `logs`
- В консоль (при DEBUG режиме)

## 🐳 Docker

### Запуск с Docker Compose (рекомендуется):

```bash
# Запуск всех сервисов
docker-compose up -d

# Просмотр логов
docker-compose logs -f

# Остановка
docker-compose down
```

### Сборка и запуск только бота:

```bash
# Сборка образа
docker build -t paintllm-bot .

# Запуск контейнера
docker run -d \
  --name paintllm-bot \
  -v $(pwd)/config.yaml:/app/config.yaml \
  -v $(pwd)/logs:/app/logs \
  paintllm-bot
```

### Управление контейнерами:

```bash
# Просмотр запущенных контейнеров
docker ps

# Просмотр логов
docker logs paintllm-bot

# Остановка контейнера
docker stop paintllm-bot

# Удаление контейнера
docker rm paintllm-bot
```

## 🧪 Тестирование

```bash
# Установка зависимостей для тестов
pip install -r paintllm-requirements.txt

# Запуск тестов
pytest tests/

# Запуск с покрытием
pytest --cov=src tests/
```

## 🤝 Contributing

1. Fork репозитория
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push в branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## ⚠️ ВАЖНО: Безопасность Midjourney API

### Как избежать бана от Discord

Discord может заблокировать ваш аккаунт, если вы:

- Спамите командами Midjourney через API
- Используете несколько Discord-аккаунтов одновременно
- Применяете общедоступные или скомпрометированные Discord токены
- Нарушаете правила Discord (ToS)

### Рекомендации:

- Используйте **только собственный аккаунт**
- **Не превышайте лимиты** (максимум 1 запрос в 10 секунд)
- **Не автоматизируйте массово**
- Работайте только в разрешённых каналах Midjourney
- Не давайте токен чужим приложениям или скриптам

### Настройка userapi.ai

1. Зарегистрируйтесь на https://userapi.ai/
2. Получите Discord Token через DevTools браузера
3. Найдите serverId и channelId для Midjourney канала
4. Настройте API ключи в конфигурации

---

**Примечание**: Этот проект использует неофициальный API для Midjourney через userapi.ai. Используйте на свой страх и риск, соблюдая все правила Discord и Midjourney.


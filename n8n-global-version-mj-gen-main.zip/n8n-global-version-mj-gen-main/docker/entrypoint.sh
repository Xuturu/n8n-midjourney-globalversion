#!/bin/sh
set -e

# Запускаем n8n в фоне
n8n start &
N8N_PID=$!

# Ожидаем, пока n8n не станет доступен по HTTP
until wget -q --spider http://localhost:5678/; do
  echo "Waiting for n8n to start..."
  sleep 2
done

# Импортируем workflow, если файл найден
if [ -f "/home/node/.n8n/workflow.json" ]; then
  echo "Found /home/node/.n8n/workflow.json. Contents:"
  head -20 /home/node/.n8n/workflow.json  # Показываем первые строки для отладки
  echo "Importing workflow..."
  n8n import:workflow --input=/home/node/.n8n/workflow.json  # Импорт workflow
  echo "Workflow import exit code: $?"
else
  echo "/home/node/.n8n/workflow.json not found. Skipping import."
fi

# Переводим n8n в foreground (контейнер не завершится)
wait $N8N_PID 